# Practice: find and fix 5 bugs

This folder has five small modules. Each has exactly one bug, and each bug is in its own file.

1. Run `python -m pytest tests/test_practice.py -q`. Five tests fail.
2. Pick one failing test and find the bug in the matching file.
3. Fix it on its own branch (one branch and one pull request per bug).
4. Open the pull request with the base branch set to `review-practice`, not `main`.

Please do not change the tests.
