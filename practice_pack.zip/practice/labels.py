def encode_label(disposition):
    # CONFIRMED -> 1, FALSE POSITIVE -> 0
    return 0 if disposition == "CONFIRMED" else 1
