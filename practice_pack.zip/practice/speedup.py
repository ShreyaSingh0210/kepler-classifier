def speedup(baseline_seconds, new_seconds):
    # how many times faster the new run is than the baseline
    return new_seconds / baseline_seconds
