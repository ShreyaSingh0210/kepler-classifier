import numpy as np


def normalize_view(view):
    # median -> 0, deepest point -> -1
    view = np.asarray(view, dtype=float)
    view = view - np.median(view)
    depth = view.min()
    if depth == 0:
        return view
    return view / depth
