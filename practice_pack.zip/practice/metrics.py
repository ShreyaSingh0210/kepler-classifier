import numpy as np


def precision_at_k(y_true, scores, k):
    # share of real planets among the k highest-scored rows
    y_true = np.asarray(y_true)
    scores = np.asarray(scores)
    top = np.argsort(scores)[:k]
    return float(y_true[top].mean())
