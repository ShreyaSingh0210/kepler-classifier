import numpy as np


def split_by_star(kepids, test_fraction=0.2, seed=0):
    # returns (train_idx, test_idx); a star must never appear on both sides
    kepids = np.asarray(kepids)
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(kepids))
    n_test = int(len(kepids) * test_fraction)
    return idx[n_test:], idx[:n_test]
