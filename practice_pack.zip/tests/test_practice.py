import numpy as np

from practice.labels import encode_label
from practice.metrics import precision_at_k
from practice.normalize import normalize_view
from practice.speedup import speedup
from practice.splits import split_by_star


def test_precision_at_k_uses_highest_scores():
    y = [1, 1, 0, 0]
    scores = [0.9, 0.8, 0.2, 0.1]
    assert precision_at_k(y, scores, 2) == 1.0
    assert precision_at_k(y, scores, 4) == 0.5


def test_split_keeps_each_star_on_one_side():
    kepids = np.repeat(np.arange(50), 3)  # 50 stars, 3 rows each
    train_idx, test_idx = split_by_star(kepids, test_fraction=0.2, seed=0)
    assert set(kepids[train_idx]).isdisjoint(set(kepids[test_idx]))
    assert len(train_idx) + len(test_idx) == len(kepids)


def test_encode_label():
    assert encode_label("CONFIRMED") == 1
    assert encode_label("FALSE POSITIVE") == 0


def test_normalize_view():
    out = normalize_view([1.0, 1.0, -1.0, 1.0, 1.0])
    assert abs(out.min() - (-1.0)) < 1e-9
    assert abs(np.median(out)) < 1e-9


def test_speedup():
    assert abs(speedup(5.11, 0.137) - 37.3) < 0.1
